package com.liuyi;

public class Demo {
	public int sum(int a,int b) {
		return a + b;
	}
}