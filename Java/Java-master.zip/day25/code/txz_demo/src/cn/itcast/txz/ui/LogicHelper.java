package cn.itcast.txz.ui;

public class LogicHelper {
	public static final int FLOOR = 0;
	public static final int WALL = 1;
	public static final int BOX = 2;
	public static final int TARGET = 4;
	public static final int BOX_AND_TARGET = 6;
}
